#ifdef ESP32

#include "Board.h"

hw_timer_t* Esp32::timer = nullptr;

#endif // ESP32
